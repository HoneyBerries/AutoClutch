package net.honeyberries;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.honeyberries.clutch.ClutchHandler;
import net.honeyberries.config.AutoClutchConfig;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_304.class_11900;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class AutoClutchClient implements ClientModInitializer {
	private static class_304 toggleKey;
	private static final ClutchHandler clutchHandler = new ClutchHandler();

	@Override
	public void onInitializeClient() {
		// Load config
		AutoClutchConfig.load();

		// Register keybinding
		toggleKey = new class_304(
				"key.autoclutch.toggle",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_B,
				class_11900.field_62556
		);
		KeyBindingHelper.registerKeyBinding(toggleKey);

		// Register tick event for clutch handler
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			clutchHandler.tick(client);

			// Handle toggle keybind
			while (toggleKey.method_1436()) {
				boolean newState = !AutoClutchConfig.getInstance().enabled;
				AutoClutchConfig.getInstance().enabled = newState;
				AutoClutchConfig.save();

				if (client.field_1724 != null) {
					String key = newState ? "text.autoclutch.enabled" : "text.autoclutch.disabled";
					client.field_1724.method_7353(class_2561.method_43471(key), true);
				}
			}
		});

		AutoClutch.LOGGER.info("AutoClutch initialized!");
	}
}