package net.honeyberries.clutch;

import net.honeyberries.config.AutoClutchConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.Random;

public class ClutchHandler {
    private static final Random random = new Random();
    private boolean isFalling = false;
    private boolean hasTriggered = false;
    private double targetDistanceBlocks = -1;

    public void tick(class_310 client) {
        if (!AutoClutchConfig.getInstance().enabled) {
            reset();
            return;
        }

        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null) {
            reset();
            return;
        }

        // Check if player is falling
        boolean currentlyFalling = player.method_18798().field_1351 < -0.5 && !player.method_24828();

        // Reset if no longer falling or on ground
        if (!currentlyFalling || player.method_24828()) {
            reset();
            return;
        }

        // Just started falling - initialize trigger distance
        if (!isFalling) {
            isFalling = true;
            hasTriggered = false;
            targetDistanceBlocks = sampleTruncatedNormal(
                    AutoClutchConfig.getInstance().meanBlocks,
                    AutoClutchConfig.getInstance().varianceBlocks,
                    AutoClutchConfig.MIN_BLOCKS,
                    AutoClutchConfig.MAX_BLOCKS
            );
        }

        // Already triggered this fall
        if (hasTriggered) {
            return;
        }

        // Check if player is holding a water bucket
        if (!isHoldingWaterBucket(player)) {
            return;
        }

        // Calculate distance to ground
        double distanceToGround = getDistanceToGround(player, client.field_1687);

        // Trigger water bucket placement when we reach target distance
        if (distanceToGround > 0 && distanceToGround <= targetDistanceBlocks) {
            placeWaterBucket(client, player);
            hasTriggered = true;
        }
    }

    private void reset() {
        isFalling = false;
        hasTriggered = false;
        targetDistanceBlocks = -1;
    }

    private boolean isHoldingWaterBucket(class_746 player) {
        class_1799 mainHand = player.method_5998(class_1268.field_5808);
        class_1799 offHand = player.method_5998(class_1268.field_5810);

        return mainHand.method_31574(class_1802.field_8705) || offHand.method_31574(class_1802.field_8705);
    }

    private double getDistanceToGround(class_746 player, class_1937 level) {
        class_243 playerPos = player.method_73189();
        class_2338.class_2339 pos = new class_2338.class_2339();

        // Start from player position and raycast downward
        double startY = playerPos.field_1351;

        // Check up to 100 blocks down
        for (int i = 0; i < 100; i++) {
            pos.method_10102(playerPos.field_1352, startY - i, playerPos.field_1350);
            class_2680 state = level.method_8320(pos);

            // Found a solid block
            if (!state.method_26215() && state.method_51367()) {
                double groundY = pos.method_10264() + 1.0; // Top of the block
                return playerPos.field_1351 - groundY;
            }
        }

        // No ground found within 100 blocks
        return -1;
    }

    private void placeWaterBucket(class_310 client, class_746 player) {
        // Determine which hand has the water bucket
        class_1268 hand = class_1268.field_5808;
        if (!player.method_5998(class_1268.field_5808).method_31574(class_1802.field_8705)) {
            hand = class_1268.field_5810;
        }

        // Use the vanilla interaction system - this creates the exact same packet as a real click
        if (client.field_1761 != null) {
            client.field_1761.method_2919(player, hand);
        }
    }

    /**
     * Sample from a truncated normal distribution.
     * Uses rejection sampling to stay within bounds.
     *
     * @param mean Mean of the distribution (in blocks)
     * @param stddev Standard deviation (in blocks)
     * @param min Minimum value (1.5 blocks)
     * @param max Maximum value (4.5 blocks)
     * @return A sampled value within bounds
     */
    private double sampleTruncatedNormal(double mean, double stddev, double min, double max) {
        double sample;
        int attempts = 0;
        final int maxAttempts = 1000; // Safety limit

        do {
            sample = mean + random.nextGaussian() * stddev;
            attempts++;

            // Safety: if we can't find a valid sample, just use the mean
            if (attempts > maxAttempts) {
                sample = Math.max(min, Math.min(max, mean));
                break;
            }
        } while (sample < min || sample > max);

        return sample;
    }
}
